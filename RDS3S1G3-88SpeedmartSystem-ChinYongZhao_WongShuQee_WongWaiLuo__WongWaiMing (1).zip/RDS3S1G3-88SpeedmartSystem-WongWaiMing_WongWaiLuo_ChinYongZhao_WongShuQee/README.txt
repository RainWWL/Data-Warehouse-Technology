================================================================================
BMIT3003 DATA WAREHOUSE TECHNOLOGY - GROUP ASSIGNMENT (ORACLE 11g XE)
README - how to run everything, and what each file is
================================================================================

This folder is the full Oracle build for the group's retail-with-membership
data warehouse: the OLTP source schema, the dimensional warehouse schema, the
ETL that loads one into the other, reporting views/indexes, and each
member's own Task 3 analytical queries.


================================================================================
SECTION 1: WHAT YOU NEED BEFORE YOU START
================================================================================

- Access to an Oracle database (Oracle 11g Express Edition, or any Oracle
  instance) and a schema/user you're allowed to create tables in.
- A client to run SQL against it: SQL*Plus (command line) or SQL Developer.
- Nothing else to install - every script here is plain SQL or PL/SQL.

Oracle doesn't have a "CREATE DATABASE" step for you to run - you're
normally given a schema/user already. Just connect to that schema/user and
run everything below inside it.


================================================================================
SECTION 2: QUICK START - RUN EVERYTHING WITH ONE FILE
================================================================================

FullScript.txt builds the whole thing end to end: OLTP schema, OLTP data
(including the bulk historical dataset), the data warehouse schema, the ETL
that loads it, and the reporting views/indexes. Run it as a single SQL*Plus
script:

    @C:\Users\wmwon\Downloads\DataWarehouseAss\FullScript.txt

A few things to expect while it runs:

  - It's a big file (~2.2 MB, ~13,000+ INSERT statements) - Oracle has no
    multi-row INSERT shortcut, so every row is its own statement. It will
    take a while; that's normal, not a hang.

  - Every CREATE TABLE/VIEW/INDEX in this script is preceded by its own
    DROP statement, so the script is safe to re-run from scratch any time
    (it rebuilds everything fresh). On your very FIRST run against a blank
    schema, those DROP statements will print harmless errors like
    "ORA-00942: table or view does not exist" or "ORA-02289: sequence does
    not exist" - there's nothing to drop yet. SQL*Plus doesn't stop on
    these; it just prints the error and moves straight on to the CREATE
    that follows. Ignore them.

  - Near the end it prints row counts for every data warehouse table, and
    a few verification queries (proof the Type 2 SCD versioning and the
    Day-2 incremental load actually worked) - check those numbers look
    sane once it finishes.

  - If it errors out somewhere in the middle for a real reason, just
    re-run the whole file again from the top once the underlying problem
    is fixed - the DROP-then-CREATE pattern means it won't collide with
    anything from the partial run.

That's the whole setup. Section 3 breaks the same content into individual
files, in case you want to run or debug one piece at a time instead.


================================================================================
SECTION 3: RUNNING THE PIECES ONE AT A TIME (same content as FullScript.txt,
split by purpose - follow this exact order, later files depend on earlier
ones)
================================================================================

  STEP 1.  Task1a_Create_OLTP
           Builds the OLTP ("operational system") schema: 23 tables
           covering customers, membership, branches, products, orders,
           delivery/pickup, payments, ratings, refunds and vouchers - plus
           the 5 Staging_* tables Task 2b will read from later.

  STEP 2.  LoadRecords_OrdersWithPattern
           Fills the OLTP tables with the original dataset (985 orders and
           all the master/reference data - customers, branches, products,
           etc). This file is long and takes a while to run - that's
           normal.

  STEP 3.  LoadDummyDataForTask2b
           Inserts the "Day-2" batch into the Staging_* tables: 15 real
           orders dated just after the initial-load cutoff, 3 brand-new
           synthetic customers, and 5 deliberately dirty rows (missing
           fields, bad data types, an invalid order type) so Task 2b's
           scrubbing logic has something real to reject.

  STEP 4.  Duplicate_Records
           Generates the extra bulk historical dataset: 250 backdated
           synthetic customers (2015-2020) and their orders, on top of the
           original 985. Cleans up any previous run of itself first (so
           it's safe to re-run), then regenerates. Run this AFTER Step 2
           and BEFORE Step 5, so the bulk data is sitting in the OLTP
           tables in time for the initial load in Step 7 to pick it up.

  STEP 5.  Task1b_Create_Dim_Fact_Table
           Builds the data warehouse schema: DATE_DIM, PRODUCT_DIM,
           BRANCH_DIM, PICKUP_DELIVERY_DIM, CUSTOMER_DIM (Type 2 SCD),
           SALES_FACT, BRANCH_STOCK_FACT, DELIVERY_RATING_FACT, plus the
           surrogate-key triggers for each dimension.

  STEP 6.  Oracle_Helper_Functions
           Three small functions - fn_try_to_number, fn_try_to_date,
           fn_try_to_timestamp - that safely convert raw/dirty text into a
           number/date/timestamp instead of erroring out. Oracle has no
           built-in TRY_CAST/TRY_CONVERT. Must run before Steps 7 and 8.

  STEP 7.  Task2a_InitialLoad_Oracle
           Creates the extraction views and load procedures, then runs
           them automatically at the bottom of the file (date range
           2015-2030, so it picks up both the original and the bulk-
           generated data from Step 4). This is what actually moves data
           from the OLTP tables into the data warehouse for the first
           time. Prints row counts for every DW table when done.

  STEP 8.  Task2b_SubsequentLoad_Oracle
           Creates the cleansing/incremental-load procedures and runs them
           automatically - processes the Day-2 batch from Step 3: loads
           the 15 clean orders, inserts the 3 new customers (into OLTP
           too, not just the warehouse), rejects the 5 dirty rows with a
           logged reason for each, and versions any customer/product whose
           details changed. Prints a rejection summary and proof the Type
           2 SCD versioning worked.

  STEP 9.  Task3_Views_Oracle
           Creates the reporting views (vw_Rpt_SalesOrders and others)
           that Task 3's analytical queries are built on.

  STEP 10. Task3_Indexes_Oracle
           Creates performance indexes on the fact tables, so Task 3's
           queries run quickly even against the full bulk dataset.

Once Step 10 finishes, the warehouse is fully built and ready to query -
move on to Section 4.


================================================================================
SECTION 4: TASK 3 - EACH MEMBER'S ANALYTICAL QUERIES
================================================================================

These are plain, read-only SELECT queries - nothing to build, and safe to
run any time after Section 2/3 is done, in any order, as many times as you
like. They don't change any data.

  Task3_RDS3S1G3_24WMR08105_WongShuQee
      Reports 1-3: monthly revenue trend, revenue by branch, order status
      breakdown, customer type (Guest/Member), membership tier value,
      voucher redemption, product category revenue, delivery vs pickup
      split.

  Task3_RDS3S1G3_24WMR07977_ChinYongZhao
      Reports 4-6: customer registration cohorts, cohort revenue/tier mix,
      repriced-item demand, revenue exposure by branch and tier, day-of-
      week and day-of-month order patterns.

  Task3_RDS3S1G3_24WMR08045_WongWaiMing
      Reports 7-9: cancellation/refund rate by branch/category/tier,
      category-by-year problem heatmap, payment method mix and failure
      rate, rating score distribution, refund reason breakdown.

  Task3_RDS3S1G3_24WMR08044_WongWaiLuo
      Reports 10-12: delivery failure revenue/rate by branch and courier,
      refund reasons for failed deliveries, customer inactivity vs
      delivery experience, active/inactive customers by membership tier,
      lifetime revenue and points by customer status.

Each file's queries are also spooled to individual CSV files (via its
matching Export_*.sql script, if you have one) for building charts.


================================================================================
SECTION 5: OPTIONAL - CHARTING THE TASK 3 RESULTS
================================================================================

make_charts.py turns exported Task 3 query CSVs into PNG charts. It's a
standalone Python script (needs pandas + matplotlib), separate from Oracle:

    python3 make_charts.py

Read the docstring at the top of the file for how it expects its input
CSVs to be named and where it writes its output.


================================================================================
SECTION 6: RESETTING YOUR SCHEMA / TROUBLESHOOTING
================================================================================

You almost never need to do this manually - re-running FullScript.txt (or
Steps 1-10 in order) already drops and rebuilds everything, since every
CREATE in this package is preceded by its own DROP. Just re-run from the
top.

If you hit a real error partway through (not one of the harmless
ORA-00942/ORA-02289 "doesn't exist yet" ones described in Section 2), copy
the exact error message - Oracle error codes look like ORA-xxxxx - that's
far faster to fix than a general "it doesn't work."

If SQL*Plus rejects a command with something like "SP2-0734: unknown
command beginning...", you likely typed the SQL*Plus prompt itself
("SQL>") along with the command. Only type what comes after it, e.g.:

    @C:\Users\wmwon\Downloads\DataWarehouseAss\FullScript.txt

not:

    SQL> @C:\Users\wmwon\Downloads\DataWarehouseAss\FullScript.txt

================================================================================
