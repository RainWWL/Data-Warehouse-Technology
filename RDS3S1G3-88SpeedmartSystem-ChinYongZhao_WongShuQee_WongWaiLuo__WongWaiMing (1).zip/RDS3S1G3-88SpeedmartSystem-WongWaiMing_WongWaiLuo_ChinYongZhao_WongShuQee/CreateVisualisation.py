"""
BMIT3003 Task 3 - Data Visualisation Script
============================================
HOW THIS WORKS (read this to learn the method, not just get the output):

1. Each Oracle query result was exported to a .csv file via SQL*Plus SPOOL
   (see Export_SetN_Oracle.sql). SQL*Plus pads columns with spaces to match
   the COLUMN FORMAT width, so every value needs .str.strip() after loading.

2. `load(path)` does exactly that: read the CSV, strip whitespace from both
   the column headers and every text cell, and convert numeric-looking
   columns to actual numbers.

3. Below that is ONE function per chart type (bar, hbar, line, pie,
   grouped_bar, stacked_bar, scatter). Each takes a small, plain-English
   config dict (which column is the label, which is the value, what to
   title it) and produces one PNG. This is the reusable part - once you
   understand these 7 functions, you can chart ANY future query by just
   calling the right one with the right column names, without writing new
   plotting code each time.

4. At the bottom, CHART_SPECS is a plain list - one row per query - saying
   which file, which chart function, and which columns to use. This is the
   only part you'd edit to add a new chart or change a chart type.

Run with: python3 make_charts.py
Output: one PNG per query, in charts_out/SetN/, named after the query.
"""

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import os

# CSV_Exports actually lives inside 07a_Task3_Queries_v2/, not at the
# project root - every Export_SetN_Oracle.sql SPOOLs there.
IN_DIR = os.path.join("07a_Task3_Queries_v2", "CSV_Exports")
OUT_DIR = "charts_out"

# ---- Consistent visual style used across every chart ----
NAVY, GOLD, RED, GREEN, GREY = "#0f3460", "#e0a800", "#c0392b", "#2e8b57", "#888888"
PALETTE = ["#0f3460", "#e0a800", "#2e8b57", "#c0392b", "#6c5ce7", "#16a085", "#d35400"]
plt.rcParams.update({
    "font.size": 10, "axes.titlesize": 13, "axes.titleweight": "bold",
    "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150,
})


def load(path):
    """Read an Oracle-SPOOL CSV: strip padding spaces from headers and values,
    then convert numeric-looking columns to real numbers."""
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    for c in df.columns:
        if df[c].dtype == object:
            df[c] = df[c].str.strip()
    for c in df.columns:
        converted = pd.to_numeric(df[c], errors="coerce")
        if converted.notna().sum() >= len(df) * 0.9:  # mostly numeric -> convert
            df[c] = converted
    return df


def _finish(fig, ax, title, out_path, title_fontsize=None):
    ax.set_title(title, fontsize=title_fontsize)
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    fig.savefig(out_path)
    plt.close(fig)
    print(f"Saved {out_path}")


def bar(df, x, y, title, out_path, color=NAVY, fmt="{:,.0f}", figsize=(8, 4.5)):
    fig, ax = plt.subplots(figsize=figsize)
    bars = ax.bar(df[x], df[y], color=color)
    ax.set_ylabel(y)
    for b, v in zip(bars, df[y]):
        ax.text(b.get_x() + b.get_width() / 2, v, fmt.format(v), ha="center", va="bottom", fontsize=8)
    plt.xticks(rotation=30, ha="right")
    _finish(fig, ax, title, out_path)


def hbar(df, x, y, title, out_path, color=NAVY, fmt="{:,.0f}", sort_desc=True, figsize=(9, 5)):
    d = df.sort_values(y, ascending=sort_desc) if sort_desc is not None else df
    fig, ax = plt.subplots(figsize=figsize)
    bars = ax.barh(d[x], d[y], color=color)
    ax.set_xlabel(y)
    for b, v in zip(bars, d[y]):
        ax.text(v, b.get_y() + b.get_height() / 2, " " + fmt.format(v), va="center", fontsize=8)
    _finish(fig, ax, title, out_path)


def line(df, x, y, title, out_path, color=NAVY, figsize=(9, 4.2), y_label=None):
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(df[x].astype(str), df[y], color=color, marker="o", markersize=3, linewidth=2)
    ax.set_ylabel(y_label or y)
    step = max(1, len(df) // 12)
    ax.set_xticks(range(0, len(df), step))
    ax.set_xticklabels(df[x].astype(str).iloc[::step], rotation=45, ha="right")
    ax.grid(axis="y", alpha=0.3)
    _finish(fig, ax, title, out_path)


def pie(df, labels, values, title, out_path, figsize=(5.5, 4.5), donut=False):
    fig, ax = plt.subplots(figsize=figsize)
    wedgeprops = dict(width=0.42) if donut else None
    ax.pie(df[values], labels=df[labels], autopct="%1.1f%%", colors=PALETTE, startangle=90,
           textprops={"fontsize": 9}, wedgeprops=wedgeprops)
    _finish(fig, ax, title, out_path)


def grouped_bar(df, x, ys, title, out_path, figsize=(8, 4.5), fmt="{:,.1f}"):
    fig, ax = plt.subplots(figsize=figsize)
    n = len(ys)
    width = 0.8 / n
    idx = range(len(df))
    for i, y in enumerate(ys):
        offset = (i - (n - 1) / 2) * width
        bars = ax.bar([p + offset for p in idx], df[y], width=width, label=y, color=PALETTE[i])
    ax.set_xticks(list(idx))
    ax.set_xticklabels(df[x], rotation=20, ha="right")
    ax.legend(fontsize=8)
    _finish(fig, ax, title, out_path)


def hgrouped_bar(df, y, ys, title, out_path, labels=None, figsize=None,
                  fmt="{:,.1f}", sort_by=None, ascending=True):
    """Horizontal clustered bar - same visual language as grouped_bar, just
    turned sideways: one cluster of side-by-side bars per category, laid
    out top-to-bottom instead of left-to-right, so category names sit on
    the y-axis and never need to be rotated no matter how many rows there
    are."""
    labels = labels or ys
    d = df.sort_values(sort_by or ys[0], ascending=ascending).reset_index(drop=True) \
        if sort_by or len(df) > 1 else df.reset_index(drop=True)
    n = len(d)
    m = len(ys)
    if figsize is None:
        figsize = (9, max(3, 0.5 * n + 1.5))
    fig, ax = plt.subplots(figsize=figsize)
    height = 0.8 / m
    idx = range(n)
    for i, col in enumerate(ys):
        offset = (i - (m - 1) / 2) * height
        bars = ax.barh([p + offset for p in idx], d[col], height=height,
                        label=labels[i], color=PALETTE[i])
        for b, v in zip(bars, d[col]):
            ax.text(v, b.get_y() + b.get_height() / 2, " " + fmt.format(v),
                    va="center", fontsize=7)
    ax.set_yticks(list(idx))
    ax.set_yticklabels(d[y])
    ax.invert_yaxis()
    ax.margins(x=0.1)
    ax.legend(fontsize=8)
    _finish(fig, ax, title, out_path)


def dumbbell(df, y, metrics, title, out_path, labels=None, colors=(NAVY, GOLD),
             figsize=None, fmt="{:.1f}", sort_by=None, ascending=True):
    """Two-metric-per-category comparison, horizontal by construction (no
    axis-crowding problem a vertical grouped bar has with many categories),
    and visually distinct from a bar chart: one dot per metric per category,
    joined by a connecting line so the GAP between the two rates (not just
    their individual heights) is the thing that reads at a glance."""
    a_col, b_col = metrics
    labels = labels or metrics
    d = df.sort_values(sort_by or a_col, ascending=ascending).reset_index(drop=True)
    n = len(d)
    if figsize is None:
        figsize = (9, max(3, 0.42 * n + 1.5))
    fig, ax = plt.subplots(figsize=figsize)
    ypos = list(range(n))
    a_vals, b_vals = d[a_col].values, d[b_col].values
    for i, (a, b) in enumerate(zip(a_vals, b_vals)):
        ax.plot([a, b], [i, i], color=GREY, lw=1.5, zorder=1, alpha=0.7)
    ax.scatter(a_vals, ypos, color=colors[0], s=70, zorder=2, label=labels[0])
    ax.scatter(b_vals, ypos, color=colors[1], s=70, zorder=2, label=labels[1])
    # offset in POINTS (fixed screen distance), not data units, so the
    # label clears the marker regardless of the chart's x-axis scale.
    for i, (a, b) in enumerate(zip(a_vals, b_vals)):
        a_left = a <= b
        ax.annotate(fmt.format(a), (a, i), xytext=(-9 if a_left else 9, 0),
                    textcoords="offset points", va="center",
                    ha="right" if a_left else "left", fontsize=7.5, color=colors[0])
        ax.annotate(fmt.format(b), (b, i), xytext=(9 if a_left else -9, 0),
                    textcoords="offset points", va="center",
                    ha="left" if a_left else "right", fontsize=7.5, color=colors[1])
    ax.set_yticks(ypos)
    ax.set_yticklabels(d[y])
    ax.invert_yaxis()
    ax.margins(x=0.12)  # room for the offset value labels near the axis edges
    ax.grid(axis="x", alpha=0.3)
    ax.legend(loc="lower right", fontsize=8, framealpha=0.9)
    _finish(fig, ax, title, out_path, title_fontsize=13 if len(title) < 55 else 11.5)


def stacked_bar_pct(df, x, category, value, title, out_path, figsize=(9, 5)):
    """100%-stacked bar: df has one row per (x, category) with a value column."""
    pivot = df.pivot(index=x, columns=category, values=value).fillna(0)
    fig, ax = plt.subplots(figsize=figsize)
    pivot.plot(kind="bar", stacked=True, ax=ax, color=PALETTE[:len(pivot.columns)])
    ax.set_ylabel(value)
    ax.legend(title=category, bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
    plt.xticks(rotation=30, ha="right")
    _finish(fig, ax, title, out_path)


def scatter(df, x, y, title, out_path, figsize=(7, 4.5), color=NAVY):
    fig, ax = plt.subplots(figsize=figsize)
    ax.scatter(df[x], df[y], color=color, s=45, alpha=0.75)
    ax.set_xlabel(x)
    ax.set_ylabel(y)
    corr = df[x].corr(df[y])
    ax.text(0.02, 0.95, f"r = {corr:.2f}", transform=ax.transAxes, fontsize=9, va="top")
    _finish(fig, ax, title, out_path)


def heatmap(df, row, title, out_path, cols=None, col=None, value=None,
            fmt="{:.1f}", cmap="YlOrRd", figsize=None, na_fill=0):
    """Matrix/heatmap chart - two shapes supported:
    - WIDE input (used for the 7.4/8.3/9.3 year-pivot reports): pass
      cols=[...] naming the already-separate value columns (e.g. the
      "2015".."2026" columns) directly, one per matrix column.
    - LONG input (used for the 8.2/9.5 two-dimension breakdowns): pass
      col=<column name> and value=<column name>, and this pivots
      (row x col -> value) internally first.
    Either way, produces one PNG with a numeric label in every cell."""
    if cols is not None:
        mat = df.set_index(row)[cols]
    else:
        mat = df.pivot(index=row, columns=col, values=value).fillna(na_fill)
    if figsize is None:
        # min width padded generously - a long "N.N [WHY] ..." title needs
        # room too, not just the matrix itself, or matplotlib clips it.
        figsize = (max(8.5, 0.55 * len(mat.columns) + 3.5), max(3, 0.42 * len(mat.index) + 1.5))
    fig, ax = plt.subplots(figsize=figsize)
    vals = mat.values.astype(float)
    im = ax.imshow(vals, cmap=cmap, aspect="auto")
    ax.set_xticks(range(len(mat.columns)))
    ax.set_xticklabels(mat.columns, rotation=45, ha="right")
    ax.set_yticks(range(len(mat.index)))
    ax.set_yticklabels(mat.index)
    vmax = vals.max() if vals.size and vals.max() > 0 else 1
    for i in range(vals.shape[0]):
        for j in range(vals.shape[1]):
            v = vals[i, j]
            ax.text(j, i, fmt.format(v), ha="center", va="center", fontsize=7,
                    color="white" if v > vmax * 0.6 else "black")
    fig.colorbar(im, ax=ax, shrink=0.8)
    _finish(fig, ax, title, out_path)


def add_combo_label(df, col_a, col_b, sep=" / ", out_col="_LABEL"):
    """Prep helper: builds a single categorical label out of two columns
    (e.g. BRANCHNAME + ORDERTYPE) so a two-dimension report can still use
    the plain bar/grouped_bar functions instead of needing a new chart type."""
    df = df.copy()
    df[out_col] = df[col_a].astype(str) + sep + df[col_b].astype(str)
    return df


# ============================================================================
# CHART_SPECS - one entry per query. This is the part you edit/extend.
#
# NOTE ON PATHS: every Export_SetN_Oracle.sql SPOOLs its CSVs flat into
# CSV_Exports/ (no per-set subfolder) - IN_DIR above points there, so every
# entry below is just the bare filename, no "SetN/" prefix.
#
# NOTE ON STALENESS (2026-09): this file predates the 5W1H rebuild of the
# Task 3 report numbering. Set 3's block below has been rewritten to match
# the CURRENT Reports 7-9 (Task3_Queries_Set3_Oracle.sql / Export_Set3_
# Oracle.sql, 7.1-7.6/8.1-8.5/9.1-9.5). Set 1 still lines up (only its old
# "Set1/" path prefix was wrong, fixed below). Sets 2 and 4 do NOT line up
# any more - Report 4/5/6/10/11/12 in this old CHART_SPECS describe an
# entirely different, older query set than what Export_Set2_Oracle.sql and
# Export_Set4_Oracle.sql actually produce now - so they're commented out
# rather than left in (they'd just crash on a missing file). Rebuild them
# the same way Set 3 was rebuilt (read the current Task3_Queries_SetN_
# Oracle.sql for real column names) before relying on their charts.
# ============================================================================
YEAR_COLS = [str(y) for y in range(2015, 2027)]

CHART_SPECS = [
    # ---- Set 1 (still current) ----
    ("1.1_monthly_revenue_trend.csv", line, dict(x="CAL_YEAR_MONTH", y="REVENUE", y_label="Revenue (RM)"), "Monthly Revenue Trend"),
    ("1.2_revenue_by_branch.csv", hbar, dict(x="BRANCHNAME", y="REVENUE", fmt="RM{:,.0f}"), "Revenue by Branch"),
    ("1.3_order_status_distribution.csv", pie, dict(labels="ORDERSTATUS", values="ORDERCOUNT"), "Order Status Distribution"),
    ("2.1_customer_count_by_tier.csv", bar, dict(x="CURRENTTIER", y="CUSTOMERCOUNT", color=GOLD), "Customer Count by Tier"),
    ("2.2_revenue_and_aov_by_tier.csv", grouped_bar, dict(x="CURRENTTIER", ys=["REVENUEPERCUSTOMER", "AVGORDERVALUE"]), "Revenue per Customer & AOV by Tier"),
    ("3.1_revenue_by_category.csv", hbar, dict(x="CATEGORYNAME", y="REVENUE", fmt="RM{:,.0f}"), "Revenue by Product Category"),
    ("3.2a_delivery_vs_pickup_split.csv", pie, dict(labels="ORDERTYPE", values="ORDERCOUNT"), "Delivery vs Pickup Split"),
    ("3.2b_delivery_vs_pickup_monthly_trend.csv", line, dict(x="CAL_YEAR_MONTH", y="DELIVERYPCT", y_label="Delivery %"), "Delivery Share Trend"),
    ("3.3_top10_products_by_revenue.csv", hbar, dict(x="PRODUCT_NAME", y="REVENUE", fmt="RM{:,.0f}"), "Top 10 Products by Revenue"),
    # 1.4/2.3/2.4/3.4 exist as new CSVs too (revenue_by_customer_type,
    # voucher_redemption_by_tier, monthly_tier_mix_trend,
    # delivery_pickup_split_by_tier) but were never chart-specced here -
    # add them the same way if you want them charted.

    # ---- Set 2 - STALE, do not run until rebuilt (see note above) ----
    # ("4.1_top_employees_by_revenue.csv", ...)  # old Report 4 was "employees"; now it's cohort analysis
    # ("5.1_avg_fulfilment_time_by_order_type.csv", ...)  # old Report 5 was "fulfilment time"; now it's repriced-item exposure
    # ("6.1_subsidy_penetration_rate.csv", ...)  # old Report 6 was "subsidy"; now it's day/hour ordering patterns

    # ---- Set 3 (Reports 7-9: Service Quality & Risk) ----
    # Filenames/columns match Task3_Queries_Set3_Oracle.sql /
    # Export_Set3_Oracle.sql as of the 5W1H rebuild (7.1-7.6, 8.1-8.5, 9.1-9.5).

    # -- Report 7: Cancellation & Refund root-cause --
    # 7.1/7.2 use a horizontal grouped bar - two bars per branch (or per
    # branch x order type), side by side, laid out top-to-bottom instead of
    # left-to-right, so branch names sit on the y-axis and never need
    # rotating no matter how many rows there are.
    ("7.1_cancel_refund_rate_by_branch.csv", hgrouped_bar,
     dict(y="BRANCHNAME", ys=["CANCELRATEPCT", "REFUNDRATEPCT"],
          labels=["Cancel %", "Refund %"], sort_by="REFUNDRATEPCT", ascending=False),
     "7.1 [WHERE] Cancellation & Refund Rate by Branch"),
    ("7.2_cancel_refund_rate_by_branch_ordertype.csv", hgrouped_bar,
     dict(y="_LABEL", ys=["CANCELRATEPCT", "REFUNDRATEPCT"],
          labels=["Cancel %", "Refund %"], sort_by="REFUNDRATEPCT", ascending=False,
          figsize=(9, 9)),
     "7.2 [WHERE+WHAT] Cancellation & Refund Rate by Branch x Order Type",
     lambda d: add_combo_label(d, "BRANCHNAME", "ORDERTYPE")),
    # 7.5/7.6 keep the dumbbell - only 3-4 rows each, so the crowding
    # problem 7.1/7.2 had doesn't apply, and the dot-and-gap framing still
    # suits a small ranked-tier comparison well.
    ("7.3_cancel_refund_rate_by_category.csv", hbar,
     dict(x="CATEGORY", y="PROBLEMRATEPCT", color=RED, fmt="{:.1f}%"),
     "7.3 [WHAT] Cancellation+Refund Rate by Category"),
    ("7.4_category_year_heatmap.csv", heatmap,
     dict(row="CATEGORY", cols=YEAR_COLS, fmt="{:.0f}", cmap="YlOrRd"),
     "7.4 [WHEN] Cancellation+Refund Rate by Category & Year"),
    ("7.5_cancel_refund_rate_by_stockrisk.csv", dumbbell,
     dict(y="RISKTIER", metrics=["CANCELRATEPCT", "REFUNDRATEPCT"],
          labels=["Cancel %", "Refund %"], sort_by="REFUNDRATEPCT", ascending=False),
     "7.5 [WHY] Cancel vs Refund Rate by Branch-Category Stock-Risk Tier"),
    ("7.6_cancel_refund_rate_by_tier.csv", dumbbell,
     dict(y="CURRENTTIER", metrics=["CANCELRATEPCT", "REFUNDRATEPCT"],
          labels=["Cancel %", "Refund %"], sort_by="REFUNDRATEPCT", ascending=False),
     "7.6 [WHO] Cancel vs Refund Rate by Customer Tier"),

    # -- Report 8: Payment Method & Failure Rate --
    # Two genuinely different questions live in the same 8.1 CSV - which
    # method is riskiest (FailureRatePct, a ranking -> hbar) and how big
    # each method's slice of total volume is (Pct, a part-of-whole ->
    # donut) - so it gets two charts instead of assuming one chart type
    # has to carry both.
    ("8.1_payment_method_mix.csv", hbar,
     dict(x="PAYMENTMETHOD", y="FAILURERATEPCT", color=RED, fmt="{:.1f}%"),
     "8.1 [WHAT] Payment Failure Rate by Method"),
    ("8.1_payment_method_mix.csv", pie,
     dict(labels="PAYMENTMETHOD", values="ORDERCOUNT", donut=True, figsize=(6, 5), out_suffix="volume_mix"),
     "8.1 [WHAT] Payment Method Volume Mix"),
    ("8.2_payment_failure_rate_by_branch_method.csv", heatmap,
     dict(row="BRANCHNAME", col="PAYMENTMETHOD", value="FAILURERATEPCT", fmt="{:.0f}", cmap="YlOrRd"),
     "8.2 [WHERE] Payment Failure Rate by Branch x Method"),
    ("8.3_payment_method_year_persistence.csv", heatmap,
     dict(row="PAYMENTMETHOD", cols=YEAR_COLS, fmt="{:.0f}", cmap="YlOrRd"),
     "8.3 [WHEN] Payment Failure Rate by Method & Year"),
    ("8.4_payment_failure_rate_by_tier.csv", bar,
     dict(x="CURRENTTIER", y="FAILURERATEPCT", color=RED, fmt="{:.1f}%"),
     "8.4 [WHO] Payment Failure Rate by Customer Tier"),
    ("8.5_payment_failure_rate_by_ordertype.csv", bar,
     dict(x="ORDERTYPE", y="FAILURERATEPCT", color=RED, fmt="{:.1f}%"),
     "8.5 [WHY] Payment Failure Rate by Fulfilment Channel"),

    # -- Report 9: Item Rating & Refund root-cause (Frozen Food/Dairy/Bakery) --
    ("9.1_rating_score_distribution.csv", bar,
     dict(x="RATINGSCORE", y="PCT", color=GOLD, fmt="{:.1f}%"),
     "9.1 [WHAT] Rating Score Distribution (Problem Categories)"),
    ("9.2_refund_reason_breakdown.csv", hbar,
     dict(x="REFUNDREASON", y="PCT", fmt="{:.1f}%"),
     "9.2 [WHY] Refund Reason Breakdown (Problem Categories)"),
    ("9.3_refund_reason_year_persistence.csv", heatmap,
     dict(row="REFUNDREASON", cols=YEAR_COLS, fmt="{:.0f}", cmap="YlOrRd"),
     "9.3 [WHEN] Refund Reason by Year (Problem Categories)"),
    ("9.4_refund_rate_by_tier.csv", bar,
     dict(x="CURRENTTIER", y="REFUNDRATEPCT", color=RED, fmt="{:.1f}%"),
     "9.4 [WHO] Refund Rate by Customer Tier (Problem Categories)"),
    ("9.5_refund_reason_by_branch.csv", heatmap,
     dict(row="BRANCHNAME", col="REFUNDREASON", value="REFUNDLINES", fmt="{:.0f}", cmap="YlOrRd"),
     "9.5 [WHERE] Refund Reason by Branch (Problem Categories)"),

    # ---- Set 4 - STALE, do not run until rebuilt (see note above) ----
    # ("10.1_delivery_volume_revenue_by_courier.csv", ...)  # filenames changed (was "courier_volume_revenue")
    # ("11.1_stock_vs_demand_by_branch.csv", ...)
    # ("11.2_branch_category_risk_tiering.csv", ...)
    # ("11.3_stock_risk_x_rating.csv", ...)
    # Report 12 (age bracket / renewal / points) no longer exists at all in
    # the current Export_Set4_Oracle.sql - only Reports 10 and 11 remain.
]

if __name__ == "__main__":
    written = 0
    for spec in CHART_SPECS:
        rel_path, func, kwargs, title = spec[:4]
        prep = spec[4] if len(spec) > 4 else None
        kwargs = dict(kwargs)  # copy - about to pop from it, and specs may be re-run
        out_suffix = kwargs.pop("out_suffix", None)
        in_path = os.path.join(IN_DIR, rel_path)
        base_name = rel_path.replace(".csv", "")
        if out_suffix:
            base_name += f"_{out_suffix}"
        out_path = os.path.join(OUT_DIR, base_name + ".png")
        try:
            df = load(in_path)
            if prep is not None:
                df = prep(df)
            func(df, title=title, out_path=out_path, **kwargs)
            written += 1
        except Exception as e:
            print(f"SKIPPED {rel_path}: {e}")
    print(f"\nDone - {written}/{len(CHART_SPECS)} charts written to {OUT_DIR}/")
